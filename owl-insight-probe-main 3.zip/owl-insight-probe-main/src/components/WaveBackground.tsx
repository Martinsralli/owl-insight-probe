import React, { useRef, useEffect } from "react";

const WaveBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const mouse = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const target = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };

    const handleMouseMove = (e: MouseEvent) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;
    };

    window.addEventListener("resize", handleResize);
    window.addEventListener("mousemove", handleMouseMove);

    // Animation parameters
    const baseAmplitude = 32;
    const baseWavelength = 420;
    const baseSpeed = 0.008;
    const smoothing = 0.08;

    function drawSoftWave(time: number) {
      // Smoothly interpolate mouse position
      mouse.current.x += (target.current.x - mouse.current.x) * smoothing;
      mouse.current.y += (target.current.y - mouse.current.y) * smoothing;

      ctx.clearRect(0, 0, width, height);
      // Create a vertical gradient for the water
      const gradient = ctx.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, "rgba(30,40,60,0.7)");
      gradient.addColorStop(1, "rgba(10,10,20,1)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Draw a single, soft, broad wave
      ctx.save();
      ctx.beginPath();
      for (let x = 0; x <= width; x += 2) {
        // The wave is centered vertically, with a gentle offset from the mouse
        const dx = x - mouse.current.x;
        const dist = Math.sqrt(dx * dx + (height / 2 - mouse.current.y) ** 2);
        const amp = baseAmplitude + Math.sin(dist / 180 - time * baseSpeed) * 10;
        const y =
          height / 2 +
          Math.sin((x + time * 60) / baseWavelength) * amp +
          Math.cos((x - time * 40) / (baseWavelength * 0.7)) * (amp / 2);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height);
      ctx.lineTo(0, height);
      ctx.closePath();
      // Soft blue overlay
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = "#3ab6ff";
      ctx.filter = "blur(6px)";
      ctx.fill();
      ctx.globalAlpha = 0.18;
      ctx.filter = "blur(16px)";
      ctx.fillStyle = "#7fd7ff";
      ctx.fill();
      ctx.filter = "none";
      ctx.globalAlpha = 1;
      ctx.restore();
    }

    function animate(time: number) {
      drawSoftWave(time);
      animationRef.current = requestAnimationFrame(animate);
    }
    animationRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mousemove", handleMouseMove);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        zIndex: 0,
        pointerEvents: "none",
      }}
    />
  );
};

export default WaveBackground; 