import React from "react";

const Dashboard: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <h1 className="text-4xl font-bold mb-4 text-foreground">Dashboard</h1>
      <p className="text-lg text-muted-foreground mb-8">Welcome to your main dashboard. More features coming soon!</p>
    </div>
  );
};

export default Dashboard; 